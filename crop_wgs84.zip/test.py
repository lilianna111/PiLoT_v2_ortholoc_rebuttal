import os
from pathlib import Path

import numpy as np

# =========================
# 直接运行配置（按需修改）
# =========================
DSM_PATH = "/media/amax/AE0E2AFD0E2ABE69/datasets/uavscene/model/DOMDSM/HKairport/dsm_wgs84.tif"
DOM_PATH = "/media/amax/AE0E2AFD0E2ABE69/datasets/uavscene/model/DOMDSM/HKairport/dom_wgs84.tif"
OUTPUT_DIR = "/home/amax/Documents/code/PiLoT/PiLoT/crop/test"
NAME = "sample"

# query pose: lon, lat, alt, roll, pitch, yaw
LON = 114.0427091112508
LAT = 22.416065856758376
ALT = 141.50411236009015
ROLL = 4.541406000587585
PITCH = 1.5399178705785226
YAW = 103.11220858726509

# 直接把 K 写死在代码里，避免再读 json 出现尺度/格式问题
K = np.array([
    [735.5326, 0.0, 586.1788],
    [0.0, 735.5326, 523.1838],
    [0.0, 0.0, 1.0],
], dtype=np.float64)

DEBUG = True
CROP_VIS = True
USE_BBOX = True
TEST_RATIO = None  # 只有 USE_BBOX=False 时才会用到

# =========================
# 兼容导入
# =========================
try:
    from proj2map_test_wgs84 import generate_ref_map
except ImportError:
    from proj2map_test import generate_ref_map

try:
    from transform_colmap_wgs84 import transform_colmap_pose_intrinsic
except ImportError:
    from transform_colmap import transform_colmap_pose_intrinsic

from utils import read_DSM_config


def ensure_dir(path: str) -> None:
    Path(path).mkdir(parents=True, exist_ok=True)


def normalize_k(k: np.ndarray) -> np.ndarray:
    k = np.array(k, dtype=np.float64)
    if k.shape != (3, 3):
        raise ValueError(f"K shape must be (3,3), got {k.shape}")
    if abs(k[2, 2]) < 1e-12:
        raise ValueError(f"Invalid K[2,2]={k[2,2]}")
    k = k / k[2, 2]
    k[2, :] = [0.0, 0.0, 1.0]
    return k


def main() -> None:
    print("=" * 100)
    print("Direct crop test")
    print("=" * 100)
    print(f"DSM_PATH   : {DSM_PATH}")
    print(f"DOM_PATH   : {DOM_PATH}")
    print(f"OUTPUT_DIR : {OUTPUT_DIR}")
    print(f"NAME       : {NAME}")
    print("pose       :")
    print(f"  lon={LON}")
    print(f"  lat={LAT}")
    print(f"  alt={ALT}")
    print(f"  roll={ROLL}")
    print(f"  pitch={PITCH}")
    print(f"  yaw={YAW}")
    print(f"USE_BBOX   : {USE_BBOX}")
    print(f"TEST_RATIO : {TEST_RATIO}")
    print("=" * 100)

    if not os.path.exists(DSM_PATH):
        raise FileNotFoundError(f"DSM 不存在: {DSM_PATH}")
    if not os.path.exists(DOM_PATH):
        raise FileNotFoundError(f"DOM 不存在: {DOM_PATH}")

    ref_rgb_path = os.path.join(OUTPUT_DIR, "ref_rgb")
    ref_depth_path = os.path.join(OUTPUT_DIR, "ref_depth")
    crop_vis_save_path = os.path.join(OUTPUT_DIR, "crop_vis")
    cache_npy_path = os.path.join(OUTPUT_DIR, "dsm_cache.npy")

    ensure_dir(OUTPUT_DIR)
    ensure_dir(ref_rgb_path)
    ensure_dir(ref_depth_path)
    if CROP_VIS:
        ensure_dir(crop_vis_save_path)
    else:
        crop_vis_save_path = None

    print("\n[1/4] 读取 DSM / DOM ...")
    geotransform, area, area_minZ, dsm_data, dsm_transform, dom_data = read_DSM_config(
        DSM_PATH, DOM_PATH, cache_npy_path
    )
    print(f"DSM shape     : {dsm_data.shape}")
    print(f"DOM shape     : {dom_data.shape}")
    print(f"area_minZ     : {area_minZ}")
    print(f"GeoTransform  : {geotransform}")

    print("\n[2/4] 构造 pose_w2c / intrinsic ...")
    pose_data = [LON, LAT, ALT, ROLL, PITCH, YAW]
    pose_w2c, intrinsic_default, q_intrinsics_info, osg_dict = transform_colmap_pose_intrinsic(pose_data)
    print("pose_w2c =")
    print(pose_w2c)

    K_used = normalize_k(K)
    print("K (hard-coded) =")
    print(K_used)
    print(f"derived image size from K: {int(round(K_used[0, 2] * 2))} x {int(round(K_used[1, 2] * 2))}")
    print(f"default intrinsic from transform_colmap =\n{intrinsic_default}")

    print("\n[3/4] 生成 crop ...")
    data = generate_ref_map(
        name=NAME,
        query_intrinsics=K_used,
        query_poses=pose_w2c,
        area_minZ=area_minZ,
        dsm_data=dsm_data,
        dsm_transform=dsm_transform,
        dom_data=dom_data,
        ref_rgb_path=ref_rgb_path,
        ref_depth_path=ref_depth_path,
        debug=DEBUG,
        crop_vis_save_path=crop_vis_save_path,
        test_ratio=TEST_RATIO,
        use_bbox=USE_BBOX,
    )

    print("\n[4/4] 输出检查 ...")
    suffix = "_bbox" if USE_BBOX else f"_ratio_{int(TEST_RATIO * 100)}"
    rgb_png = os.path.join(ref_rgb_path, f"{NAME}_dom.png")
    rgb_jpg = os.path.join(ref_rgb_path, f"{NAME}{suffix}_dom.jpg")
    depth_npy = os.path.join(ref_depth_path, f"{NAME}{suffix}_dom.npy")
    mask_png = os.path.join(ref_rgb_path, f"{NAME}{suffix}_dom_mask.png")

    print("generate_ref_map return =")
    print(data)

    for p in [rgb_png, rgb_jpg, depth_npy, mask_png]:
        print(f"exists? {p} -> {os.path.exists(p)}")
        if p.endswith(".npy") and os.path.exists(p):
            arr = np.load(p)
            print(f"  npy shape={arr.shape}, dtype={arr.dtype}, finite_ratio={np.isfinite(arr).mean():.6f}")

    print("\n完成。")


if __name__ == "__main__":
    main()
